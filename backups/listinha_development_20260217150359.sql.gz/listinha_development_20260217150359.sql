--
-- PostgreSQL database dump
--

\restrict 5AHUwIttV3eIDcfy4d71dUAiwsgW9HZ4AOeBJloNYnYnSnuZatZtvMetBS5OsMH

-- Dumped from database version 14.20 (Ubuntu 14.20-0ubuntu0.22.04.1)
-- Dumped by pg_dump version 14.20 (Ubuntu 14.20-0ubuntu0.22.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: ar_internal_metadata; Type: TABLE; Schema: public; Owner: xita
--

CREATE TABLE public.ar_internal_metadata (
    key character varying NOT NULL,
    value character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.ar_internal_metadata OWNER TO xita;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: xita
--

CREATE TABLE public.categories (
    id bigint NOT NULL,
    name character varying,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.categories OWNER TO xita;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: xita
--

CREATE SEQUENCE public.categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categories_id_seq OWNER TO xita;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: xita
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: category_tasks; Type: TABLE; Schema: public; Owner: xita
--

CREATE TABLE public.category_tasks (
    id bigint NOT NULL,
    category_id bigint NOT NULL,
    task_id bigint NOT NULL,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.category_tasks OWNER TO xita;

--
-- Name: category_tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: xita
--

CREATE SEQUENCE public.category_tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.category_tasks_id_seq OWNER TO xita;

--
-- Name: category_tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: xita
--

ALTER SEQUENCE public.category_tasks_id_seq OWNED BY public.category_tasks.id;


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: xita
--

CREATE TABLE public.schema_migrations (
    version character varying NOT NULL
);


ALTER TABLE public.schema_migrations OWNER TO xita;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: xita
--

CREATE TABLE public.tasks (
    id bigint NOT NULL,
    title character varying,
    description text,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL,
    user_id bigint NOT NULL
);


ALTER TABLE public.tasks OWNER TO xita;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: xita
--

CREATE SEQUENCE public.tasks_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tasks_id_seq OWNER TO xita;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: xita
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: xita
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    email character varying DEFAULT ''::character varying NOT NULL,
    encrypted_password character varying DEFAULT ''::character varying NOT NULL,
    reset_password_token character varying,
    reset_password_sent_at timestamp(6) without time zone,
    remember_created_at timestamp(6) without time zone,
    created_at timestamp(6) without time zone NOT NULL,
    updated_at timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO xita;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: xita
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO xita;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: xita
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: xita
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: category_tasks id; Type: DEFAULT; Schema: public; Owner: xita
--

ALTER TABLE ONLY public.category_tasks ALTER COLUMN id SET DEFAULT nextval('public.category_tasks_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: xita
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: xita
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: ar_internal_metadata; Type: TABLE DATA; Schema: public; Owner: xita
--

COPY public.ar_internal_metadata (key, value, created_at, updated_at) FROM stdin;
environment	development	2023-04-21 20:35:52.366651	2023-04-21 20:35:52.366651
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: xita
--

COPY public.categories (id, name, created_at, updated_at) FROM stdin;
1	Tarefas Domésticas	2023-04-22 02:28:59.765835	2023-04-22 02:28:59.765835
2	Educação	2023-04-22 02:28:59.772479	2023-04-22 02:28:59.772479
3	Saúde	2023-04-22 02:28:59.777107	2023-04-22 02:28:59.777107
4	Mercado	2023-04-22 02:28:59.781791	2023-04-22 02:28:59.781791
\.


--
-- Data for Name: category_tasks; Type: TABLE DATA; Schema: public; Owner: xita
--

COPY public.category_tasks (id, category_id, task_id, created_at, updated_at) FROM stdin;
7	4	2	2023-04-22 02:51:55.667222	2023-04-22 02:51:55.667222
8	4	4	2023-04-22 02:52:15.174983	2023-04-22 02:52:15.174983
9	2	5	2023-04-22 02:53:47.653171	2023-04-22 02:53:47.653171
10	3	5	2023-04-22 02:53:47.656218	2023-04-22 02:53:47.656218
11	2	6	2023-04-22 02:54:17.527826	2023-04-22 02:54:17.527826
12	2	7	2023-04-22 05:08:29.503212	2023-04-22 05:08:29.503212
13	4	7	2023-04-22 05:08:29.506421	2023-04-22 05:08:29.506421
17	2	15	2023-06-07 22:53:41.673986	2023-06-07 22:53:41.673986
18	3	15	2023-06-07 22:53:41.676516	2023-06-07 22:53:41.676516
19	4	15	2023-06-07 22:53:41.678992	2023-06-07 22:53:41.678992
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: xita
--

COPY public.schema_migrations (version) FROM stdin;
20230421214804
20230421234621
20230422005656
20230422021404
20230422021815
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: xita
--

COPY public.tasks (id, title, description, created_at, updated_at, user_id) FROM stdin;
2	comprar leite	leite 2L	2023-04-22 01:24:46.348404	2023-04-22 02:51:55.682582	1
4	comprar pão	5 pães	2023-04-22 02:52:15.170299	2023-04-22 02:52:15.170299	1
5	Estudar medicina	estudar 5 horas	2023-04-22 02:53:47.648254	2023-04-22 02:53:47.648254	1
6	Estudar matemática	Estudar algebra	2023-04-22 02:54:17.522975	2023-04-22 02:54:17.522975	1
7	estudar panificação	estudar sobre fermento	2023-04-22 05:08:29.495636	2023-04-22 05:08:29.495636	1
13	aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa	bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb	2023-05-02 00:08:17.131758	2023-05-02 00:08:17.131758	1
15	yyyyyyyyy	oooooooo	2023-06-07 22:53:41.670367	2023-06-07 22:53:41.670367	4
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: xita
--

COPY public.users (id, email, encrypted_password, reset_password_token, reset_password_sent_at, remember_created_at, created_at, updated_at) FROM stdin;
1	a@a.com	$2a$12$CElU8..FClaw0rWT/.bZf.lqnvq0nqn/1WooU891eBx341st1wuwG	\N	\N	\N	2023-04-22 01:24:00.506494	2023-04-22 01:24:00.506494
2	b@b.com	$2a$12$TkqMpoBzwyahZYJfwNw8ge2N0.UHbM4ecpJtWGRMkTa0atlNLW4u.	\N	\N	\N	2023-04-22 01:25:10.171757	2023-04-22 01:25:10.171757
3	c@c.com	$2a$12$O8sOS1fPhSXSiBBg5CffS.7cy9Y39gZyqdHj5T8TlXjCDB17mdE42	\N	\N	\N	2023-05-25 00:07:29.678676	2023-05-25 00:07:29.678676
4	xitarps@gmail.com	$2a$12$mZvraITfGFtvnhZKT6dZrO3eREp4FPSam8Nwd8e.AWspZSGef8rTm	\N	\N	\N	2023-06-07 22:51:51.951325	2023-06-07 22:51:51.951325
5	z@z.com		\N	\N	\N	2026-02-17 01:55:43.922799	2026-02-17 01:55:43.922799
7	ff@ff.com		\N	\N	\N	2026-02-17 02:04:37.284965	2026-02-17 02:04:37.284965
\.


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: xita
--

SELECT pg_catalog.setval('public.categories_id_seq', 4, true);


--
-- Name: category_tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: xita
--

SELECT pg_catalog.setval('public.category_tasks_id_seq', 19, true);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: xita
--

SELECT pg_catalog.setval('public.tasks_id_seq', 15, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: xita
--

SELECT pg_catalog.setval('public.users_id_seq', 7, true);


--
-- Name: ar_internal_metadata ar_internal_metadata_pkey; Type: CONSTRAINT; Schema: public; Owner: xita
--

ALTER TABLE ONLY public.ar_internal_metadata
    ADD CONSTRAINT ar_internal_metadata_pkey PRIMARY KEY (key);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: xita
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: category_tasks category_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: xita
--

ALTER TABLE ONLY public.category_tasks
    ADD CONSTRAINT category_tasks_pkey PRIMARY KEY (id);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: xita
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: xita
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: xita
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: index_category_tasks_on_category_id; Type: INDEX; Schema: public; Owner: xita
--

CREATE INDEX index_category_tasks_on_category_id ON public.category_tasks USING btree (category_id);


--
-- Name: index_category_tasks_on_task_id; Type: INDEX; Schema: public; Owner: xita
--

CREATE INDEX index_category_tasks_on_task_id ON public.category_tasks USING btree (task_id);


--
-- Name: index_tasks_on_user_id; Type: INDEX; Schema: public; Owner: xita
--

CREATE INDEX index_tasks_on_user_id ON public.tasks USING btree (user_id);


--
-- Name: index_users_on_email; Type: INDEX; Schema: public; Owner: xita
--

CREATE UNIQUE INDEX index_users_on_email ON public.users USING btree (email);


--
-- Name: index_users_on_reset_password_token; Type: INDEX; Schema: public; Owner: xita
--

CREATE UNIQUE INDEX index_users_on_reset_password_token ON public.users USING btree (reset_password_token);


--
-- Name: category_tasks fk_rails_455941be2e; Type: FK CONSTRAINT; Schema: public; Owner: xita
--

ALTER TABLE ONLY public.category_tasks
    ADD CONSTRAINT fk_rails_455941be2e FOREIGN KEY (category_id) REFERENCES public.categories(id);


--
-- Name: tasks fk_rails_4d2a9e4d7e; Type: FK CONSTRAINT; Schema: public; Owner: xita
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT fk_rails_4d2a9e4d7e FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: category_tasks fk_rails_9efd72a0c7; Type: FK CONSTRAINT; Schema: public; Owner: xita
--

ALTER TABLE ONLY public.category_tasks
    ADD CONSTRAINT fk_rails_9efd72a0c7 FOREIGN KEY (task_id) REFERENCES public.tasks(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 5AHUwIttV3eIDcfy4d71dUAiwsgW9HZ4AOeBJloNYnYnSnuZatZtvMetBS5OsMH

